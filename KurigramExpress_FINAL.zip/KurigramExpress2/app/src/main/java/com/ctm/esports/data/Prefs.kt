package com.ctm.esports.data

import android.content.Context

class Prefs(ctx: Context) {
    private val p = ctx.getSharedPreferences("ke_prefs", Context.MODE_PRIVATE)

    var lastLat: Double get() = p.getString("lat","0.0")!!.toDouble() set(v) = p.edit().putString("lat","$v").apply()
    var lastLng: Double get() = p.getString("lng","0.0")!!.toDouble() set(v) = p.edit().putString("lng","$v").apply()
    var lastSpeed: Double get() = p.getString("spd","0.0")!!.toDouble() set(v) = p.edit().putString("spd","$v").apply()
    var lastRoute: String get() = p.getString("route","") ?: "" set(v) = p.edit().putString("route",v).apply()
    var lastUpdated: Long get() = p.getLong("ts",0L) set(v) = p.edit().putLong("ts",v).apply()

    fun hasLocation() = lastLat != 0.0 && lastLng != 0.0
}
