package com.ctm.esports.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.ctm.esports.data.FirebaseRepository
import com.ctm.esports.databinding.ActivityMainBinding
import com.ctm.esports.ui.contributor.ContributorActivity
import com.ctm.esports.ui.viewer.ViewerActivity
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.btnContributor.setOnClickListener {
            startActivity(Intent(this, ContributorActivity::class.java))
        }
        b.btnViewer.setOnClickListener {
            startActivity(Intent(this, ViewerActivity::class.java))
        }
        b.tvFacebook.setOnClickListener {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.facebook.com/jahid.hasan.rabbi.chilmari")))
        }
        b.tvTelegram.setOnClickListener {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/ctmtools")))
        }

        lifecycleScope.launch {
            FirebaseRepository.observeTotalUsers().collectLatest {
                b.tvTotalUsers.text = "মোট ব্যবহারকারী: $it"
            }
        }
        lifecycleScope.launch {
            FirebaseRepository.observeLiveCount().collectLatest {
                b.tvLiveNow.text = "এখন লাইভ: $it জন"
            }
        }
    }
}
