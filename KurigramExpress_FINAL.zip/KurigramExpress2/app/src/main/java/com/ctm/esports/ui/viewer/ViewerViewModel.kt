package com.ctm.esports.ui.viewer

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ctm.esports.data.FirebaseRepository
import com.ctm.esports.data.Prefs
import com.ctm.esports.model.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class ViewerViewModel : ViewModel() {

    private val _data = MutableStateFlow<LiveTrainData?>(null)
    val data: StateFlow<LiveTrainData?> = _data

    private val _online = MutableStateFlow(true)
    val online: StateFlow<Boolean> = _online

    private val _totalUsers = MutableStateFlow(0L)
    val totalUsers: StateFlow<Long> = _totalUsers

    fun start(ctx: Context) {
        val prefs = Prefs(ctx)

        viewModelScope.launch {
            FirebaseRepository.observeLiveUsers()
                .catch { _online.value = false }
                .collect { locations ->
                    _online.value = true
                    if (locations.isEmpty()) { _data.value = null; return@collect }

                    val avgLat = locations.map { it.lat }.average()
                    val avgLng = locations.map { it.lng }.average()
                    val avgSpeed = locations.map { it.speed }.average()
                    val count = locations.size
                    val confidence = minOf(count * 15, 100)

                    val routeStr = locations.groupBy { it.route }.maxByOrNull { it.value.size }?.key ?: ""
                    val route = if (routeStr == TrainRoute.DHAKA_TO_KURIGRAM.value)
                        TrainRoute.DHAKA_TO_KURIGRAM else TrainRoute.KURIGRAM_TO_DHAKA

                    val si = stationInfo(avgLat, avgLng, avgSpeed, route)

                    _data.value = LiveTrainData(
                        avgLat = avgLat, avgLng = avgLng, avgSpeed = avgSpeed,
                        activeUsers = count, confidence = confidence,
                        lastUpdated = System.currentTimeMillis(),
                        currentStation = si.current, nextStation = si.next,
                        distanceToNext = si.distToNext, etaMinutes = si.etaMin,
                        isStopped = avgSpeed < 5.0, routeProgress = si.progress,
                        route = route.displayName
                    )

                    prefs.lastLat = avgLat; prefs.lastLng = avgLng
                    prefs.lastSpeed = avgSpeed; prefs.lastUpdated = System.currentTimeMillis()
                }
        }

        viewModelScope.launch {
            FirebaseRepository.observeTotalUsers().collect { _totalUsers.value = it }
        }
    }
}
