package com.ctm.esports.model

import kotlin.math.*

data class Station(val name: String, val lat: Double, val lng: Double)

data class TrainLocation(
    val lat: Double = 0.0,
    val lng: Double = 0.0,
    val speed: Double = 0.0,
    val accuracy: Float = 0f,
    val timestamp: Long = 0L,
    val route: String = ""
)

data class LiveTrainData(
    val avgLat: Double,
    val avgLng: Double,
    val avgSpeed: Double,
    val activeUsers: Int,
    val confidence: Int,
    val lastUpdated: Long,
    val currentStation: String,
    val nextStation: String,
    val distanceToNext: Double,
    val etaMinutes: Double,
    val isStopped: Boolean,
    val routeProgress: Float,
    val route: String
)

enum class TrainRoute(val displayName: String, val value: String) {
    KURIGRAM_TO_DHAKA("Kurigram → Dhaka", "kurigram_to_dhaka"),
    DHAKA_TO_KURIGRAM("Dhaka → Kurigram", "dhaka_to_kurigram")
}

object RouteData {
    val stations = listOf(
        Station("কুড়িগ্রাম", 25.8075, 89.6355),
        Station("চিলমারী", 25.5069, 89.6773),
        Station("উলিপুর", 25.6578, 89.5869),
        Station("লালমনিরহাট", 25.9228, 89.4520),
        Station("রংপুর", 25.7439, 89.2752),
        Station("পার্বতীপুর", 25.6500, 88.9119),
        Station("সৈয়দপুর", 25.7760, 88.8990),
        Station("নাটোর", 24.4203, 88.9826),
        Station("সান্তাহার", 24.7550, 88.9700),
        Station("জয়দেবপুর", 23.9979, 90.3951),
        Station("বিমানবন্দর", 23.8433, 90.4005),
        Station("কমলাপুর", 23.7336, 90.4261)
    )

    fun forRoute(route: TrainRoute) =
        if (route == TrainRoute.DHAKA_TO_KURIGRAM) stations.reversed() else stations
}

fun haversine(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
    val R = 6371.0
    val dLat = Math.toRadians(lat2 - lat1)
    val dLon = Math.toRadians(lon2 - lon1)
    val a = sin(dLat / 2).pow(2) +
            cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2).pow(2)
    return R * 2 * atan2(sqrt(a), sqrt(1 - a))
}

fun bearing(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Float {
    val dLon = Math.toRadians(lon2 - lon1)
    val y = sin(dLon) * cos(Math.toRadians(lat2))
    val x = cos(Math.toRadians(lat1)) * sin(Math.toRadians(lat2)) -
            sin(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * cos(dLon)
    return ((Math.toDegrees(atan2(y, x)) + 360) % 360).toFloat()
}

fun stationInfo(lat: Double, lng: Double, speed: Double, route: TrainRoute): StationInfo {
    val list = RouteData.forRoute(route)
    var closestIdx = 0
    var minDist = Double.MAX_VALUE

    list.forEachIndexed { i, s ->
        val d = haversine(lat, lng, s.lat, s.lng)
        if (d < minDist) { minDist = d; closestIdx = i }
    }

    val atStation = minDist <= 0.5
    val current = if (atStation) "🚉 ${list[closestIdx].name}" else {
        val prev = list.getOrNull(closestIdx - 1)
        if (prev != null) "${prev.name} → ${list[closestIdx].name}" else list[closestIdx].name
    }

    val nextIdx = if (atStation) closestIdx + 1 else closestIdx
    val next = list.getOrNull(nextIdx)
    val distNext = if (next != null) haversine(lat, lng, next.lat, next.lng) else 0.0
    val eta = if (speed > 5.0 && next != null) (distNext / speed) * 60.0 else 0.0

    // progress
    val first = list.first()
    val covered = haversine(first.lat, first.lng, lat, lng)
    val total = list.zipWithNext().sumOf { (a, b) -> haversine(a.lat, a.lng, b.lat, b.lng) }
    val progress = ((covered / total) * 100).coerceIn(0.0, 100.0).toFloat()

    return StationInfo(current, next?.name ?: "গন্তব্য", distNext, eta, progress)
}

data class StationInfo(
    val current: String,
    val next: String,
    val distToNext: Double,
    val etaMin: Double,
    val progress: Float
)
