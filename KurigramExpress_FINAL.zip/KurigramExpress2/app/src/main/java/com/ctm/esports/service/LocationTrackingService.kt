package com.ctm.esports.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.location.Location
import android.os.*
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.*
import com.ctm.esports.App
import com.ctm.esports.R
import com.ctm.esports.data.FirebaseRepository
import com.ctm.esports.data.Prefs
import com.ctm.esports.model.TrainLocation
import com.ctm.esports.ui.MainActivity
import kotlinx.coroutines.*

class LocationTrackingService : Service() {

    companion object {
        const val ACTION_START = "START"
        const val ACTION_STOP = "STOP"
        const val EXTRA_ROUTE = "route"
        const val NOTIF_ID = 1001

        fun start(ctx: Context, route: String) {
            val i = Intent(ctx, LocationTrackingService::class.java).apply {
                action = ACTION_START; putExtra(EXTRA_ROUTE, route)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) ctx.startForegroundService(i)
            else ctx.startService(i)
        }

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, LocationTrackingService::class.java).apply { action = ACTION_STOP })
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var fusedClient: FusedLocationProviderClient
    private lateinit var prefs: Prefs
    private var route = ""
    private var callback: LocationCallback? = null

    override fun onBind(i: Intent?) = null

    override fun onCreate() {
        super.onCreate()
        fusedClient = LocationServices.getFusedLocationProviderClient(this)
        prefs = Prefs(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                route = intent.getStringExtra(EXTRA_ROUTE) ?: ""
                startForeground(NOTIF_ID, buildNotif("GPS চালু হচ্ছে..."))
                FirebaseRepository.setOnDisconnect()
                startUpdates()
            }
            ACTION_STOP -> stopTracking()
        }
        return START_STICKY
    }

    private fun startUpdates() {
        val req = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 5000L)
            .setMinUpdateIntervalMillis(5000L)
            .setGranularity(Granularity.GRANULARITY_FINE)
            .build()

        callback = object : LocationCallback() {
            override fun onLocationResult(r: LocationResult) {
                r.lastLocation?.let { process(it) }
            }
        }
        try {
            fusedClient.requestLocationUpdates(req, callback!!, Looper.getMainLooper())
        } catch (e: SecurityException) { stopSelf() }
    }

    private fun process(loc: Location) {
        if (loc.accuracy > 50f) return

        val speedKmh = if (loc.hasSpeed()) loc.speed * 3.6 else 0.0
        val newInterval = when {
            loc.accuracy <= 15f -> 5000L
            loc.accuracy <= 30f -> 15000L
            else -> 30000L
        }

        val trainLoc = TrainLocation(
            lat = loc.latitude, lng = loc.longitude,
            speed = speedKmh, accuracy = loc.accuracy,
            timestamp = System.currentTimeMillis(), route = route
        )

        prefs.lastLat = loc.latitude; prefs.lastLng = loc.longitude
        prefs.lastSpeed = speedKmh; prefs.lastRoute = route
        prefs.lastUpdated = System.currentTimeMillis()

        scope.launch { FirebaseRepository.pushLocation(trainLoc) }

        val signal = when { loc.accuracy <= 15f -> "🟢 ভালো" ; loc.accuracy <= 30f -> "🟡 মাঝারি"; else -> "🔴 দুর্বল" }
        updateNotif("গতি: ${String.format("%.0f", speedKmh)} km/h | সিগনাল: $signal")
    }

    private fun stopTracking() {
        callback?.let { fusedClient.removeLocationUpdates(it) }
        scope.launch { FirebaseRepository.removeMyLocation() }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun buildNotif(text: String): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, App.CHANNEL_ID)
            .setContentTitle("🚂 কুড়িগ্রাম এক্সপ্রেস — লাইভ ট্র্যাকিং")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_train)
            .setContentIntent(pi)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateNotif(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotif(text))
    }

    override fun onDestroy() {
        super.onDestroy()
        callback?.let { fusedClient.removeLocationUpdates(it) }
        scope.cancel()
    }
}
