package com.ctm.esports.ui.contributor

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.android.material.snackbar.Snackbar
import com.ctm.esports.databinding.ActivityContributorBinding
import com.ctm.esports.model.TrainRoute
import com.ctm.esports.service.LocationTrackingService
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class ContributorActivity : AppCompatActivity() {

    private lateinit var b: ActivityContributorBinding
    private var selectedRoute: TrainRoute? = null
    private var isTracking = false

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        if (perms[Manifest.permission.ACCESS_FINE_LOCATION] == true) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) askBackground()
            else startTracking()
        } else {
            Snackbar.make(b.root, "লোকেশন পারমিশন দিন!", Snackbar.LENGTH_LONG).show()
        }
    }

    private val bgPermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { startTracking() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityContributorBinding.inflate(layoutInflater)
        setContentView(b.root)

        setSupportActionBar(b.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        b.toolbar.setNavigationOnClickListener { finish() }

        b.chipKurigramToDhaka.setOnClickListener {
            selectedRoute = TrainRoute.KURIGRAM_TO_DHAKA
            b.chipKurigramToDhaka.isChecked = true
            b.chipDhakaToKurigram.isChecked = false
            b.btnStart.isEnabled = true
        }
        b.chipDhakaToKurigram.setOnClickListener {
            selectedRoute = TrainRoute.DHAKA_TO_KURIGRAM
            b.chipDhakaToKurigram.isChecked = true
            b.chipKurigramToDhaka.isChecked = false
            b.btnStart.isEnabled = true
        }

        b.btnStart.setOnClickListener {
            if (isTracking) stopTracking() else checkAndStart()
        }
    }

    private fun checkAndStart() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            == PackageManager.PERMISSION_GRANTED) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) askBackground() else startTracking()
        } else {
            permLauncher.launch(arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ))
        }
    }

    private fun askBackground() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_BACKGROUND_LOCATION)
            != PackageManager.PERMISSION_GRANTED) {
            AlertDialog.Builder(this)
                .setTitle("ব্যাকগ্রাউন্ড লোকেশন")
                .setMessage("অ্যাপ বন্ধ থাকলেও ট্র্যাকিং চালু রাখতে 'সব সময়' লোকেশন অনুমতি দিন।")
                .setPositiveButton("দিন") { _, _ ->
                    bgPermLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
                }
                .setNegativeButton("পরে") { _, _ -> startTracking() }
                .show()
        } else startTracking()
    }

    private fun startTracking() {
        val route = selectedRoute ?: return
        isTracking = true
        LocationTrackingService.start(this, route.value)
        b.btnStart.text = "⏹ ট্র্যাকিং বন্ধ করুন"
        b.btnStart.setBackgroundColor(getColor(android.R.color.holo_red_dark))
        b.cardStatus.visibility = View.VISIBLE
        b.tvRoute.text = "রুট: ${route.displayName}"
        b.chipKurigramToDhaka.isEnabled = false
        b.chipDhakaToKurigram.isEnabled = false

        // Pulse animation
        lifecycleScope.launch {
            while (isTracking) {
                b.ivLive.animate().alpha(0.2f).setDuration(600).start()
                delay(600)
                b.ivLive.animate().alpha(1f).setDuration(600).start()
                delay(600)
            }
        }
        Snackbar.make(b.root, "✅ লাইভ ট্র্যাকিং শুরু হয়েছে!", Snackbar.LENGTH_SHORT).show()
    }

    private fun stopTracking() {
        isTracking = false
        LocationTrackingService.stop(this)
        b.btnStart.text = "▶ লাইভ ট্র্যাকিং শুরু করুন"
        b.btnStart.setBackgroundColor(getColor(android.R.color.holo_green_dark))
        b.cardStatus.visibility = View.GONE
        b.chipKurigramToDhaka.isEnabled = true
        b.chipDhakaToKurigram.isEnabled = true
        Snackbar.make(b.root, "ট্র্যাকিং বন্ধ। ধন্যবাদ! 🙏", Snackbar.LENGTH_SHORT).show()
    }
}
