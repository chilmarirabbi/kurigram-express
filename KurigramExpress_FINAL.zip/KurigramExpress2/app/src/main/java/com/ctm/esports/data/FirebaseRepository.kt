package com.ctm.esports.data

import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.ctm.esports.model.TrainLocation
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

object FirebaseRepository {

    private val db = FirebaseDatabase.getInstance("https://ctm-e-sports-default-rtdb.firebaseio.com")
    private val liveRef get() = db.getReference("train/kurigram_express/live_users")
    private val statsRef get() = db.getReference("app_stats")
    private val uid get() = FirebaseAuth.getInstance().currentUser?.uid

    suspend fun pushLocation(loc: TrainLocation): Boolean {
        val u = uid ?: return false
        return try {
            liveRef.child(u).setValue(mapOf(
                "lat" to loc.lat, "lng" to loc.lng,
                "speed" to loc.speed, "accuracy" to loc.accuracy,
                "timestamp" to loc.timestamp, "route" to loc.route
            )).await()
            true
        } catch (e: Exception) { false }
    }

    suspend fun removeMyLocation() {
        try { uid?.let { liveRef.child(it).removeValue().await() } } catch (e: Exception) { }
    }

    fun observeLiveUsers(): Flow<List<TrainLocation>> = callbackFlow {
        val listener = object : ValueEventListener {
            override fun onDataChange(snap: DataSnapshot) {
                val now = System.currentTimeMillis()
                val list = snap.children.mapNotNull { c ->
                    try {
                        val ts = c.child("timestamp").getValue(Long::class.java) ?: 0L
                        if (now - ts > 180_000L) return@mapNotNull null
                        TrainLocation(
                            lat = c.child("lat").getValue(Double::class.java) ?: return@mapNotNull null,
                            lng = c.child("lng").getValue(Double::class.java) ?: return@mapNotNull null,
                            speed = c.child("speed").getValue(Double::class.java) ?: 0.0,
                            accuracy = c.child("accuracy").getValue(Float::class.java) ?: 100f,
                            timestamp = ts,
                            route = c.child("route").getValue(String::class.java) ?: ""
                        )
                    } catch (e: Exception) { null }
                }
                trySend(list)
            }
            override fun onCancelled(err: DatabaseError) { close(err.toException()) }
        }
        liveRef.addValueEventListener(listener)
        awaitClose { liveRef.removeEventListener(listener) }
    }

    fun observeLiveCount(): Flow<Int> = callbackFlow {
        val listener = object : ValueEventListener {
            override fun onDataChange(snap: DataSnapshot) {
                val now = System.currentTimeMillis()
                val count = snap.children.count { c ->
                    val ts = c.child("timestamp").getValue(Long::class.java) ?: 0L
                    now - ts <= 180_000L
                }
                trySend(count)
            }
            override fun onCancelled(err: DatabaseError) { close(err.toException()) }
        }
        liveRef.addValueEventListener(listener)
        awaitClose { liveRef.removeEventListener(listener) }
    }

    fun observeTotalUsers(): Flow<Long> = callbackFlow {
        val listener = object : ValueEventListener {
            override fun onDataChange(snap: DataSnapshot) {
                trySend(snap.child("total_users").getValue(Long::class.java) ?: 0L)
            }
            override fun onCancelled(err: DatabaseError) { close(err.toException()) }
        }
        statsRef.addValueEventListener(listener)
        awaitClose { statsRef.removeEventListener(listener) }
    }

    fun incrementTotalUsers() {
        statsRef.child("total_users").runTransaction(object : Transaction.Handler {
            override fun doTransaction(data: MutableData): Transaction.Result {
                data.value = (data.getValue(Long::class.java) ?: 0L) + 1
                return Transaction.success(data)
            }
            override fun onComplete(e: DatabaseError?, b: Boolean, d: DataSnapshot?) {}
        })
    }

    fun setOnDisconnect() {
        uid?.let { liveRef.child(it).onDisconnect().removeValue() }
    }
}
