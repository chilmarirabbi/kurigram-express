package com.ctm.esports.ui.viewer

import android.animation.ValueAnimator
import android.graphics.*
import android.os.Bundle
import android.view.View
import android.view.animation.LinearInterpolator
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.gms.maps.*
import com.google.android.gms.maps.model.*
import com.ctm.esports.R
import com.ctm.esports.databinding.ActivityViewerBinding
import com.ctm.esports.model.LiveTrainData
import com.ctm.esports.model.RouteData
import com.ctm.esports.model.bearing
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class ViewerActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var b: ActivityViewerBinding
    private val vm: ViewerViewModel by viewModels()
    private var map: GoogleMap? = null
    private var trainMarker: Marker? = null
    private var lastLat = 0.0; private var lastLng = 0.0
    private var animator: ValueAnimator? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityViewerBinding.inflate(layoutInflater)
        setContentView(b.root)
        setSupportActionBar(b.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        b.toolbar.setNavigationOnClickListener { finish() }

        b.mapView.onCreate(savedInstanceState)
        b.mapView.getMapAsync(this)

        vm.start(this)
        observe()
    }

    override fun onMapReady(gMap: GoogleMap) {
        map = gMap
        gMap.mapType = GoogleMap.MAP_TYPE_NORMAL
        gMap.uiSettings.isZoomControlsEnabled = true
        gMap.moveCamera(CameraUpdateFactory.newLatLngZoom(LatLng(24.5, 89.5), 7f))

        // Draw route line
        val pts = RouteData.stations.map { LatLng(it.lat, it.lng) }
        gMap.addPolyline(PolylineOptions().addAll(pts)
            .color(Color.parseColor("#1565C0")).width(6f).geodesic(true))

        // Station dots
        RouteData.stations.forEach { s ->
            gMap.addMarker(MarkerOptions()
                .position(LatLng(s.lat, s.lng)).title(s.name)
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE))
                .anchor(0.5f, 0.5f))
        }
    }

    private fun observe() {
        lifecycleScope.launch {
            vm.data.collectLatest { data ->
                if (data != null) showData(data) else showEmpty()
            }
        }
        lifecycleScope.launch {
            vm.online.collectLatest { online ->
                b.bannerOffline.visibility = if (online) View.GONE else View.VISIBLE
            }
        }
        lifecycleScope.launch {
            vm.totalUsers.collectLatest { b.tvTotalUsers.text = "মোট ব্যবহারকারী: $it" }
        }
    }

    private fun showData(d: LiveTrainData) {
        b.tvNoData.visibility = View.GONE
        b.cardInfo.visibility = View.VISIBLE

        b.tvSpeed.text = String.format("%.0f km/h", d.avgSpeed)
        b.tvStatus.text = if (d.isStopped) "⏸ থামানো" else "🚂 চলছে"
        b.tvStatus.setBackgroundColor(
            Color.parseColor(if (d.isStopped) "#DA3633" else "#2DA44E"))
        b.tvCurrentStation.text = d.currentStation
        b.tvNextStation.text = "পরের স্টেশন: ${d.nextStation}"
        b.tvDistance.text = String.format("%.1f কিমি দূরে", d.distanceToNext)
        b.tvEta.text = if (d.isStopped || d.etaMinutes <= 0) "ETA: —"
            else "ETA: ~${d.etaMinutes.toInt()} মিনিট"
        b.tvRoute.text = "রুট: ${d.route}"
        b.tvActiveUsers.text = "সক্রিয়: ${d.activeUsers} জন"
        b.tvConfidence.text = "নির্ভরযোগ্যতা: ${d.confidence}%"
        b.progressConfidence.progress = d.confidence
        b.progressRoute.progress = d.routeProgress.toInt()
        b.tvProgress.text = "${d.routeProgress.toInt()}%"
        b.tvLastUpdated.text = "আপডেট: ${SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(d.lastUpdated))}"

        updateMarker(d)
    }

    private fun updateMarker(d: LiveTrainData) {
        val gMap = map ?: return
        val newPos = LatLng(d.avgLat, d.avgLng)
        val brg = if (lastLat != 0.0) bearing(lastLat, lastLng, d.avgLat, d.avgLng) else 0f

        if (trainMarker == null) {
            trainMarker = gMap.addMarker(MarkerOptions()
                .position(newPos).title("কুড়িগ্রাম এক্সপ্রেস")
                .icon(trainIcon()).anchor(0.5f, 0.5f).flat(true).rotation(brg))
            gMap.animateCamera(CameraUpdateFactory.newLatLngZoom(newPos, 10f))
        } else {
            animateMarker(newPos, brg)
        }
        lastLat = d.avgLat; lastLng = d.avgLng
    }

    private fun animateMarker(target: LatLng, targetBrg: Float) {
        val marker = trainMarker ?: return
        animator?.cancel()
        val sLat = marker.position.latitude; val sLng = marker.position.longitude
        val sBrg = marker.rotation

        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1000L; interpolator = LinearInterpolator()
            addUpdateListener { anim ->
                val f = anim.animatedFraction
                val lat = sLat + f * (target.latitude - sLat)
                val lng = sLng + f * (target.longitude - sLng)
                var diff = targetBrg - sBrg
                if (diff > 180) diff -= 360; if (diff < -180) diff += 360
                marker.position = LatLng(lat, lng)
                marker.rotation = sBrg + f * diff
                marker.setIcon(trainIcon())
            }
            start()
        }
    }

    private fun trainIcon(): BitmapDescriptor {
        val size = 120
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        cv.drawCircle(60f, 60f, 56f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#1565C0") })
        cv.drawCircle(60f, 60f, 56f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 6f })
        cv.drawText("🚂", 60f, 78f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 54f; textAlign = Paint.Align.CENTER })
        return BitmapDescriptorFactory.fromBitmap(bmp)
    }

    private fun showEmpty() {
        b.cardInfo.visibility = View.GONE
        b.tvNoData.visibility = View.VISIBLE
    }

    override fun onResume() { super.onResume(); b.mapView.onResume() }
    override fun onPause() { super.onPause(); b.mapView.onPause() }
    override fun onStart() { super.onStart(); b.mapView.onStart() }
    override fun onStop() { super.onStop(); b.mapView.onStop() }
    override fun onDestroy() { super.onDestroy(); animator?.cancel(); b.mapView.onDestroy() }
    override fun onSaveInstanceState(out: Bundle) { super.onSaveInstanceState(out); b.mapView.onSaveInstanceState(out) }
    override fun onLowMemory() { super.onLowMemory(); b.mapView.onLowMemory() }
    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}
