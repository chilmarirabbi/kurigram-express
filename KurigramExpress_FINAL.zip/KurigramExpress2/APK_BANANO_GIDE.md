# 🚂 কুড়িগ্রাম এক্সপ্রেস — APK বানানোর সহজ গাইড

## মাত্র ৫টি ধাপে APK পাবেন — কোনো PC লাগবে না!

---

## ধাপ ১: GitHub Account বানান

1. যান: **github.com**
2. Sign up করুন (free)
3. Username, Email, Password দিন

---

## ধাপ ২: নতুন Repository বানান

1. GitHub এ লগিন করুন
2. উপরে ডানে **+** বাটন → **"New repository"**
3. Repository name: `kurigram-express`
4. **Public** রাখুন
5. **"Create repository"** ক্লিক করুন

---

## ধাপ ৩: ফাইল আপলোড করুন

1. **"uploading an existing file"** ক্লিক করুন
2. ZIP ফাইলের ভেতরের সব ফাইল/ফোল্ডার আপলোড করুন
   (ZIP খুলুন → KurigramExpress2 ফোল্ডারের ভেতরের সব কিছু)
3. নিচে **"Commit changes"** ক্লিক করুন

---

## ধাপ ৪: Build চালু হবে আপনাআপনি

1. Repository তে যান → **"Actions"** ট্যাব
2. **"Build APK"** workflow দেখবেন — চলছে 🟡
3. ৫-৮ মিনিট অপেক্ষা করুন
4. সবুজ ✅ হলে সফল!

---

## ধাপ ৫: APK Download করুন

1. Actions → Build APK → সর্বশেষ run ক্লিক
2. নিচে **"Artifacts"** সেকশন
3. **"KurigramExpress-APK"** ডাউনলোড করুন
4. ZIP খুলুন → **app-debug.apk** পাবেন
5. ফোনে install করুন ✅

---

## ⚠️ গুরুত্বপূর্ণ: Firebase Rules সেট করুন

Firebase Console → Realtime Database → Rules → এটা paste করুন:

```json
{
  "rules": {
    "train": {
      "kurigram_express": {
        "live_users": {
          ".read": true,
          "$uid": {
            ".write": "auth !== null && auth.uid === $uid"
          }
        }
      }
    },
    "app_stats": {
      ".read": true,
      "total_users": {
        ".write": "auth !== null"
      }
    }
  }
}
```

---

## ✅ সব হয়ে গেলে

- অ্যাপ খুলুন
- **"আমি কুড়িগ্রাম এক্সপ্রেসে আছি"** → ট্রেনে থাকলে শেয়ার করুন
- **"লাইভ ম্যাপ খুলুন"** → ট্রেন দেখুন

---

## 📞 সমস্যা হলে

- **Telegram:** https://t.me/ctmtools
- **Facebook:** https://www.facebook.com/jahid.hasan.rabbi.chilmari
